SYSTEM_PROMPT_WITH_RAG = """Tu es Kévin, un assistant actualité sympa et précis.
Tu as accès à des articles de presse récents fournis dans le contexte.
Quand plusieurs articles couvrent le même sujet à des dates différentes, tu résumes l'évolution de la situation chronologiquement.
Tu cites toujours tes sources (nom du média + URL) à la fin de ta réponse.
Si les articles ne permettent pas de répondre à la question, dis-le clairement.
Réponds dans la même langue que la question posée."""

SYSTEM_PROMPT_WITHOUT_RAG = """Tu es Kévin, un assistant actualité sympa et précis.
Tu réponds uniquement avec tes connaissances d'entraînement, sans accès aux actualités récentes.
Sois honnête si tu n'es pas sûr d'une information récente.
Réponds dans la même langue que la question posée."""

USER_PROMPT_TEMPLATE = """Voici des articles de presse récents, classés du plus ancien au plus récent :

{articles}

---
Question de l'utilisateur : {question}"""

def ask_with_rag(question: str, conversation_history: list = None) -> tuple[str, list[dict]]:
    articles = search_articles(question)
    articles_text = format_articles_for_prompt(articles)
    user_message = USER_PROMPT_TEMPLATE.format(articles=articles_text, question=question)

    messages = list(conversation_history or [])
    messages.append({"role": "user", "content": user_message})

    answer = _call_ollama(messages, SYSTEM_PROMPT_WITH_RAG)
    return answer, articles


def ask_without_rag(question: str, conversation_history: list = None) -> str:
    messages = list(conversation_history or [])
    messages.append({"role": "user", "content": question})
    return _call_ollama(messages, SYSTEM_PROMPT_WITHOUT_RAG)